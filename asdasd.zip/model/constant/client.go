package constant

const (
	Shadowrocket = "shadowrocket"
	Clash        = "clash"
	V2rayN       = "v2rayn"
	NekoBox      = "nekobox"
	Happ         = "happ"
)
